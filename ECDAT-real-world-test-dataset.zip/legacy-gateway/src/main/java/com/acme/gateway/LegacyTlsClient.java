package com.acme.gateway;

import javax.net.ssl.SSLContext;

public class LegacyTlsClient {

    public SSLContext createLegacyContext() throws Exception {
        // Intentional legacy TLS marker for ECDAT configuration discovery.
        return SSLContext.getInstance("TLSv1.1");
    }

    public String algorithm() {
        return "RSA/ECB/PKCS1Padding";
    }
}

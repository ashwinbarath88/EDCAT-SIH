Legacy partner gateway used for compatibility testing.

Migration candidates intentionally represented:
- TLS 1.1
- RSA 1024-bit
- 3DES
- SHA-1
- RSA PKCS#1 v1.5

All endpoints in this dataset use .invalid hostnames and are non-production examples.

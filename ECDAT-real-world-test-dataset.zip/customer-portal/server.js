const crypto = require("crypto");
const express = require("express");

const app = express();

// Intentional legacy hash for ECDAT discovery.
function legacyPasswordFingerprint(password) {
  return crypto.createHash("md5").update(password).digest("hex");
}

// Intentional SHA-1 compatibility path.
function legacyDocumentId(document) {
  return crypto.createHash("sha1").update(document).digest("hex");
}

// Modern example for contrast.
function secureToken() {
  return crypto.randomBytes(32).toString("hex");
}

app.get("/health", (_req, res) => {
  res.json({ service: "customer-portal", status: "ok" });
});

module.exports = app;

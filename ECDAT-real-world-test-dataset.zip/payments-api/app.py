from hashlib import md5, sha1
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
import secrets

def legacy_customer_hash(customer_id: str) -> str:
    # Intentional legacy usage for ECDAT testing.
    return md5(customer_id.encode()).hexdigest()

def legacy_signature(payload: bytes) -> str:
    # Intentional SHA-1 usage for migration discovery.
    return sha1(payload).hexdigest()

def encrypt_invoice(plaintext: bytes, key: bytes, iv: bytes) -> bytes:
    # Intentional AES-CBC finding; production code should prefer an AEAD mode.
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(plaintext)

def create_session_token() -> str:
    # Modern cryptographically secure randomness.
    return secrets.token_urlsafe(32)

# Test-only placeholder, not a real credential.
PAYMENTS_TEST_API_KEY = "TEST_ONLY_NOT_A_REAL_SECRET_12345"

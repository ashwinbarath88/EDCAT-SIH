# ECDAT Practical Real-World Test Dataset

Synthetic enterprise-style codebase for testing ECDAT crypto discovery and map generation.

IMPORTANT:
- All credentials, hostnames, emails, IDs and keys are fictional/test-only.
- Nothing here is a real secret.
- The dataset intentionally contains a mixture of modern, legacy, weak and configuration-based cryptography.

Services:
- payments-api: Python/FastAPI-style payment service
- customer-portal: Node/Express-style web portal
- order-service: Java/Spring-style service
- data-worker: Go worker
- legacy-gateway: legacy Java integration service

Expected discovery examples include:
- MD5
- SHA-1
- DES / 3DES
- AES-CBC
- RSA-1024
- RSA-PKCS1-v1_5
- TLS 1.0 / TLS 1.1
- weak random generation
- hard-coded test keys
- modern AES-GCM / SHA-256 / RSA-2048 examples for comparison

Run ECDAT against this entire folder, not the ZIP itself if your prototype expects a directory.

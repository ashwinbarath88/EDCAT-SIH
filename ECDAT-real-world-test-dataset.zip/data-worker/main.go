package main

import (
    "crypto/md5"
    "crypto/sha256"
    "fmt"
)

func legacyRecordKey(value string) string {
    // Intentional MD5 finding.
    return fmt.Sprintf("%x", md5.Sum([]byte(value)))
}

func modernRecordKey(value string) string {
    // Modern comparison path.
    return fmt.Sprintf("%x", sha256.Sum256([]byte(value)))
}

func main() {
    fmt.Println(legacyRecordKey("TEST-ORDER-1001"))
    fmt.Println(modernRecordKey("TEST-ORDER-1001"))
}

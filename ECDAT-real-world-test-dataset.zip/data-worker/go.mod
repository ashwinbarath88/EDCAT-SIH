module example.com/acme/data-worker

go 1.22

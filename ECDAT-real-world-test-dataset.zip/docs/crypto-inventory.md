# Expected ECDAT discovery inventory

| System | File | Expected signal | Category |
|---|---|---|---|
| payments-api | app.py | MD5 | hashing |
| payments-api | app.py | SHA-1 | hashing |
| payments-api | app.py | AES-CBC | symmetric encryption |
| customer-portal | server.js | MD5 | hashing |
| customer-portal | server.js | SHA-1 | hashing |
| customer-portal | tls.conf | TLS 1.0 / 1.1 | transport |
| order-service | CryptoUtil.java | SHA-1 | hashing |
| order-service | CryptoUtil.java | DES | symmetric encryption |
| data-worker | main.go | MD5 | hashing |
| legacy-gateway | LegacyTlsClient.java | TLS 1.1 | transport |
| legacy-gateway | gateway.properties | RSA 1024 | asymmetric encryption |
| legacy-gateway | gateway.properties | 3DES | symmetric encryption |
| legacy-gateway | gateway.properties | SHA-1 | hashing |
| legacy-gateway | gateway.properties | RSA PKCS#1 v1.5 | asymmetric encryption |
| infra | nginx.conf | TLS 1.0 / 1.1 | transport |

This table is a test oracle, not a claim about real enterprise systems.
